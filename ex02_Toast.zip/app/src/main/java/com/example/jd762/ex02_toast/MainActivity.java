package com.example.jd762.ex02_toast;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnIntent;
    EditText editText;
    LinearLayout Main;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText =(EditText)findViewById(R.id.editText);
        btnIntent=(Button)findViewById(R.id.btnIntent);

        btnIntent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NextActivity.class);
                intent.putExtra("name",editText.getText().toString());
                startActivity(intent);
                finish();
            }
        });




        //1. Toast 예제 실습

//        Toast.makeText(getApplicationContext(),"출력할 문자열",Toast.LENGTH_LONG ).show();
        Toast toast = Toast.makeText(getApplicationContext(),"출력할 문자열",Toast.LENGTH_LONG );
//        toast.show();
        //context 부분에 3가지 방법으로 띄울 수 있다.
        // this
        // getActivityContext()
        // [Activity 클래스이름}.this
        // 토스트 위치 이동
        int offX = 0, offY = 0;
//        toast.setGravity(Gravity.CENTER, offX, offY);
//        toast.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL,0,0);
//        toast.setGravity(Gravity.TOP|Gravity.LEFT,0,0);

        //백그라운드 변경
        /*TextView view = new TextView(getApplicationContext);
        view.setText("변경");
        view.setBackgroundColor(getApplicationContext);*/

        TextView msg = (TextView)findViewById(R.id.txtMessage);
        msg.setText("message" );
        msg.setBackgroundColor(getResources().getColor(android.R.color.white));
        toast.setGravity(Gravity.BOTTOM,0,300);
//        toast.show();
//        toast.cancel();  -- 화면 해제
    }


}